/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_42sh_pguitar_define.h                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pguitar <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/19 16:11:57 by pguitar           #+#    #+#             */
/*   Updated: 2020/01/19 16:12:01 by pguitar          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_42SH_PGUITAR_DEFINE_H
# define FT_42SH_PGUITAR_DEFINE_H

# define MSG_ALIAS_42SH				"alias"
# define MSG_UNALIAS_42SH			"unalias"

#endif
