# Тест только для redirect

ls >>>fthfghfg
ftghfghfghgf
