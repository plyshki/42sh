# Тест только для redirect

ls <<