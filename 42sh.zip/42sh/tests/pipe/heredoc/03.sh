# Тест только для heredoc

cat -e << 'БРЕД'


