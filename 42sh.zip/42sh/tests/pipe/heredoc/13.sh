# Тест только для heredoc
cat -e <<   dgdfgdfgdfgdfgdfвыпавпвапвапвапва


echo 'Отобразиться'