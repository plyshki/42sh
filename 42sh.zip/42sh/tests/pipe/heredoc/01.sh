# Тест только для heredoc

cat -e <<БРЕД
Привет! " #
'EOF

echo 'fghjghjghjhhg'