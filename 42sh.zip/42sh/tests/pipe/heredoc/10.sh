# Тест только для heredoc
cat -e << БРЕД -b | cat -e

dsgd
${zz:?
БРЕД
echo 'Не отобразиться'