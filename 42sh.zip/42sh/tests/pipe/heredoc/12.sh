# Тест только для heredoc
cat -e <<   


echo 'Не Отобразиться'