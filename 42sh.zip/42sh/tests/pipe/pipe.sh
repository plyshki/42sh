# Тест только для pipe


#  ##############################
ls | cat -e | cat -b | cat | cat | cat | cat | cat | cat


echo "dfhgdfhfghfghfghfghfghf
jngjghj" | cat -e | cat -b | cat | cat | cat | cat | cat | cat

ls dfgdfgd 2>&1 fhfghgf | cat -e | cat -b | cat | cat | cat | cat | cat | cat

#  ############################################################
echo 'Тут будет уже различия между оболочками'


# Ошибки в синтаксисе ##############################
echo 'Тестируем: ошибки в синтаксисе'
 ./redirect/01.sh;echo $?
 ./redirect/02.sh;echo $?



# ##############################
echo 'Это должно всегда отображаться'

