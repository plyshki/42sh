# Тест только для expansion

${sss=:kkkkhggfhf}
echo 'not run'