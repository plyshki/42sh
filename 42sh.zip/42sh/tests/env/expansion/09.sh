# Тест только для expansion

${
	
}
echo 'not run'