# Тест только для expansion

${13123gdfgdf=dfgdfgdfgdf}
echo 'not run'