# Тест только для expansion

unset sss
${sss:?}; echo 'Не отобразить'


echo 'отобразить'