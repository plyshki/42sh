# Тест только для inhibitors

echo \${HOMES=test
ghjgh ftghfg

}

\${HOMES=test
ghjgh ftghfg

}
