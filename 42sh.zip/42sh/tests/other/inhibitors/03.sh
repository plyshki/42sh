# Тест только для inhibitors

echo ''"
"
\"'
'"'"'