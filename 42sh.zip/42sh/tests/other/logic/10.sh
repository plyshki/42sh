# Тест только для logic

unset zzzz
ls && echo ${zzzz:?}
echo 'end'