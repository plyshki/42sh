# Тест только для logic

unset zzzz
echo ${zzzz:?} || ls
echo 'end'