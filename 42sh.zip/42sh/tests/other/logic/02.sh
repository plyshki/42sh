# Тест только для logic
||
echo 'end'