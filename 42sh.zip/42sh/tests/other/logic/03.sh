# Тест только для logic
ls &&
echo 'end'