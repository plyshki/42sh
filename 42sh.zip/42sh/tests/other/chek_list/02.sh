# Тест только для chek_list

echo '
- Execute the following command and check that the display is correct:
$> exit 999999999999999999999999999999999999999999
Check that the 42shs behavior is consistent and that no crashes occur.
or undetermined behaviour has occurred.

'
exit 999999999999999999999999999999999999999999