# Тест только для export

export +++++111zzz4=fgjjghjg
echo $zzz4

