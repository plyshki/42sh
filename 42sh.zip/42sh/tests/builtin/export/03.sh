# Тест только для export

export 111zzz4=fgjjghjg zz=dfgdgddg
echo $zzz4 $zz

