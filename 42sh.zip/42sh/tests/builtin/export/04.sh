# Тест только для export

export @=ghjghjgh