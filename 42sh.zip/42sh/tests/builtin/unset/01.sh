# Тест только для unset

unset ? ! $

