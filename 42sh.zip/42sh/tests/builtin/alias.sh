# Тест только для alias

alias a=1
alias b=a
alias c=
alias d='
'
alias e=qwerty f=фывфыава g=фывфыава123124qwerty
alias h='asdasdas
sdasdas
sda       sad'
alias a
alias a b c
alias h e d g f
alias e= d= c= f= g= h= b= a= c=
alias
alias 12837481212=asd
alias 12837481212


alias !=!
alias @=@
alias \#=\#
alias %=%
alias ^=^
alias \*=\*
alias №=№
alias ! @ \# % ^ \* №
alias


alias a='asd'
alias a
alias a="asseq213w" a=1 a=2 a=3 b='qqq' a=123
alias b a
alias g=0 a=2 c=3 b=4 d=7 e=5 h=6 f=1
alias g a c b d e h f


alias abcdefgh=
alias abcdefgh
unalias abcdefgh
alias abcdefgh
alias
unalias a b c d e f g h
alias
unalias ! @ \# % ^ \* № 12837481212
alias


alias $=1
alias -=1
alias aaaa=1
alias aaaa
alias aaa
alias 111 asioa 39293 wjpa asp slsd 12owqpo2

# ##############################
echo 'Это должно всегда отображаться'