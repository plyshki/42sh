echo a | echo b | echo b | exit 0 | echo end
