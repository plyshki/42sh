echo aaa
exit 256
echo bbb
