echo aaa
exit 11 22
