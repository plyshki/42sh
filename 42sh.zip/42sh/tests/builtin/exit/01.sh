echo aaa
exit a
echo bbb
