echo aaa
exit
echo bbb
