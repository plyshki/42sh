echo aaa
exit 42
echo bbb
