echo gyjfg  9<&2 9<&1 
cat 
exit 0
./redirect.sh
read
exit 0