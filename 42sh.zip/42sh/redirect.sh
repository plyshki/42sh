# Тест только для redirect


ls 9<&2 9<&1 9>&2


echo "fgtjhfhjfgвапрварварва" 